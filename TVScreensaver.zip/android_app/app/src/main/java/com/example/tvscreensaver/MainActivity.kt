package com.example.tvscreensaver

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import java.io.IOException
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private var webServer: WebServer? = null
    private lateinit var sharedPref: android.content.SharedPreferences
    private lateinit var layoutWallpapers: android.widget.LinearLayout
    private lateinit var tvInstructions: TextView

    // Navigation Views
    private lateinit var navEsp32: TextView
    private lateinit var navWallpaper: TextView
    private lateinit var navClock: TextView
    private lateinit var navPreview: TextView
    private lateinit var navDrive: TextView
    private lateinit var navList: TextView

    // Content Views
    private lateinit var contentEsp32: android.view.View
    private lateinit var contentWallpaper: android.view.View
    private lateinit var contentClock: android.view.View
    private lateinit var contentPreview: android.view.View
    private lateinit var contentDrive: android.view.View
    private lateinit var contentList: android.view.View
    
    // Google Drive
    private var mGoogleSignInClient: GoogleSignInClient? = null
    private var mDriveServiceHelper: DriveServiceHelper? = null

    private val importLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            importWallpaper(it)
        }
    }

    private val folderBrowserLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val folderPath = result.data?.getStringExtra("folder_path")
            folderPath?.let {
                importFromFolderPath(it)
            }
        }
    }
    
    private val signInLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        android.util.Log.d("GoogleSignIn", "Result code: ${result.resultCode}")
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
                android.util.Log.d("GoogleSignIn", "Account email: ${account.email}")
                handleSignInResult(account)
            } catch (e: com.google.android.gms.common.api.ApiException) {
                android.util.Log.e("GoogleSignIn", "Sign-in failed with status code: ${e.statusCode}", e)
                e.printStackTrace()
                android.widget.Toast.makeText(this, "Sign-in failed: ${e.statusCode} - ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        } else {
            android.util.Log.e("GoogleSignIn", "Sign-in cancelled or failed. Result code: ${result.resultCode}")
            android.widget.Toast.makeText(this, "Sign-in cancelled", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)

            // Enable logo in ActionBar
            supportActionBar?.setDisplayShowHomeEnabled(true)
            supportActionBar?.setLogo(R.drawable.ic_launcher)
            supportActionBar?.setDisplayUseLogoEnabled(true)

            sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)

            // Request storage permissions
            requestStoragePermissions()

            // Initialize Navigation Views
            navEsp32 = findViewById(R.id.nav_esp32)
            navWallpaper = findViewById(R.id.nav_wallpaper)
            navClock = findViewById(R.id.nav_clock)
            navPreview = findViewById(R.id.nav_preview)
            navDrive = findViewById(R.id.nav_drive)
            navList = findViewById(R.id.nav_list)

            // Initialize Content Views
            contentEsp32 = findViewById(R.id.content_esp32)
            contentWallpaper = findViewById(R.id.content_wallpaper)
            contentClock = findViewById(R.id.content_clock)
            contentPreview = findViewById(R.id.content_preview)
            contentDrive = findViewById(R.id.content_drive)
            contentList = findViewById(R.id.content_list)

            setupNavigation()

            val etEspIp = findViewById<EditText>(R.id.etEspIp)
            val btnSave = findViewById<Button>(R.id.btnSave)
            tvInstructions = findViewById(R.id.tvInstructions)
            val btnImport = findViewById<Button>(R.id.btnImport)
            val btnSelectFolder = findViewById<Button>(R.id.btnSelectFolder)
            val rgMode = findViewById<android.widget.RadioGroup>(R.id.rgMode)
            val rbStatic = findViewById<android.widget.RadioButton>(R.id.rbStatic)
            val rbRotating = findViewById<android.widget.RadioButton>(R.id.rbRotating)
            val spinnerInterval = findViewById<android.widget.Spinner>(R.id.spinnerInterval)
            val layoutInterval = findViewById<android.widget.LinearLayout>(R.id.layoutInterval)
            layoutWallpapers = findViewById(R.id.layoutWallpapers)
            
            // Google Drive UI
            val btnGoogleSignIn = findViewById<Button>(R.id.btnGoogleSignIn)
            val btnSelectDriveFolder = findViewById<Button>(R.id.btnSelectDriveFolder)
            val tvDriveFolderName = findViewById<TextView>(R.id.tvDriveFolderName)

            // Load ESP IP
            etEspIp.setText(sharedPref.getString("esp_ip", ""))

            btnSave.setOnClickListener {
                val ip = etEspIp.text.toString()
                sharedPref.edit().putString("esp_ip", ip).apply()
            }

            // Import Button
            btnImport.setOnClickListener {
                importLauncher.launch(arrayOf("image/*"))
            }

            // Select Folder Button (Local)
            btnSelectFolder.setOnClickListener {
                val intent = Intent(this, FolderBrowserActivity::class.java)
                folderBrowserLauncher.launch(intent)
            }
            
            // Google Sign In Configuration
            val clientId = "950906764084-mhseibibbaqk7b2mqadv9v95tbldep1f.apps.googleusercontent.com"
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(Scope(DriveScopes.DRIVE_READONLY))
                .requestIdToken(clientId)
                .build()
            mGoogleSignInClient = GoogleSignIn.getClient(this, gso)
            
            btnGoogleSignIn.setOnClickListener {
                signIn()
            }
            
            btnSelectDriveFolder.setOnClickListener {
                openDriveFolderPicker()
            }
            
            // Check if already signed in
            val account = GoogleSignIn.getLastSignedInAccount(this)
            if (account != null) {
                handleSignInResult(account)
            } else {
                tvDriveFolderName.text = "Not signed in"
            }

            // Mode Selection
            val currentMode = sharedPref.getString("wallpaper_mode", "rotating")
            if (currentMode == "static") {
                rbStatic.isChecked = true
                layoutInterval.visibility = android.view.View.GONE
            } else {
                rbRotating.isChecked = true
                layoutInterval.visibility = android.view.View.VISIBLE
            }

            rgMode.setOnCheckedChangeListener { _, checkedId ->
                val mode = if (checkedId == R.id.rbStatic) "static" else "rotating"
                sharedPref.edit().putString("wallpaper_mode", mode).apply()
                layoutInterval.visibility = if (mode == "rotating") android.view.View.VISIBLE else android.view.View.GONE
            }

            // Interval Spinner
            val intervals = arrayOf("15 Seconds", "30 Seconds", "1 Minute", "5 Minutes", "10 Minutes")
            val intervalValues = arrayOf(15, 30, 60, 300, 600)
            val adapter = android.widget.ArrayAdapter(this, R.layout.spinner_item, intervals)
            adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
            spinnerInterval.adapter = adapter

            val savedInterval = sharedPref.getInt("rotation_interval", 30)
            val spinnerPosition = intervalValues.indexOf(savedInterval)
            if (spinnerPosition >= 0) {
                spinnerInterval.setSelection(spinnerPosition)
            }

            spinnerInterval.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                    sharedPref.edit().putInt("rotation_interval", intervalValues[position]).apply()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
            }

            // Clock Style Spinner
            val spinnerClockStyle = findViewById<android.widget.Spinner>(R.id.spinnerClockStyle)
            val clockStyles = arrayOf(
                "Classic Bold",
                "Modern Thin", 
                "Digital Mono",
                "Elegant Script",
                "Retro Condensed",
                "Futuristic",
                "Minimalist Light",
                "Bold Italic",
                "Rounded Casual",
                "Sharp Serif",
                "Playful Sans",
                "Professional",
                "Artistic Handwritten"
            )
            val clockStyleAdapter = android.widget.ArrayAdapter(this, R.layout.spinner_item, clockStyles)
            clockStyleAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
            spinnerClockStyle.adapter = clockStyleAdapter

            val savedClockStyle = sharedPref.getString("clock_style", "Classic Bold")
            val clockStylePosition = clockStyles.indexOf(savedClockStyle)
            if (clockStylePosition >= 0) {
                spinnerClockStyle.setSelection(clockStylePosition)
            }

            spinnerClockStyle.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                    sharedPref.edit().putString("clock_style", clockStyles[position]).apply()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
            }

            // Clock Position Spinner
            val spinnerClockPosition = findViewById<android.widget.Spinner>(R.id.spinnerClockPosition)
            val clockPositions = arrayOf("Bottom-Right", "Bottom-Center", "Bottom-Left", "Mid-Right", "Center", "Mid-Left", "Top-Right", "Top-Center", "Top-Left")
            val clockPositionAdapter = android.widget.ArrayAdapter(this, R.layout.spinner_item, clockPositions)
            clockPositionAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
            spinnerClockPosition.adapter = clockPositionAdapter

            val savedClockPosition = sharedPref.getString("clock_position", "Bottom-Right")
            val clockPositionPosition = clockPositions.indexOf(savedClockPosition)
            if (clockPositionPosition >= 0) {
                spinnerClockPosition.setSelection(clockPositionPosition)
            }

            spinnerClockPosition.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                    sharedPref.edit().putString("clock_position", clockPositions[position]).apply()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
            }
            
            // Text Size SeekBar
            val seekBarTextSize = findViewById<android.widget.SeekBar>(R.id.seekBarTextSize)
            val tvTextSizeLabel = findViewById<TextView>(R.id.tvTextSizeLabel)
            
            // Range: 0.5x to 2.0x. Progress 0-150. 50 = 1.0x
            val savedTextScale = sharedPref.getFloat("text_scale", 1.0f)
            val progress = ((savedTextScale - 0.5f) * 100).toInt()
            seekBarTextSize.progress = progress
            tvTextSizeLabel.text = String.format("Text Size: %.1fx", savedTextScale)
            
            seekBarTextSize.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                    val scale = 0.5f + (progress / 100f)
                    tvTextSizeLabel.text = String.format("Text Size: %.1fx", scale)
                    sharedPref.edit().putFloat("text_scale", scale).apply()
                }
                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
            })

            // Load Wallpapers List
            loadWallpaperList()

            // Start Web Server
            startWebServer()

            // Preview Button
            val btnPreview = findViewById<android.widget.Button>(R.id.btnPreview)
            btnPreview.setOnClickListener {
                val intent = android.content.Intent(this, PreviewActivity::class.java)
                startActivity(intent)
            }

        } catch (e: Exception) {
            e.printStackTrace()
            val errorView = TextView(this)
            errorView.text = "Error starting app:\n${e.stackTraceToString()}"
            errorView.setTextColor(android.graphics.Color.RED)
            errorView.textSize = 16f
            errorView.setPadding(32, 32, 32, 32)
            setContentView(errorView)
        }
    }

    private fun startWebServer() {
        try {
            webServer = WebServer(this, 8080)
            webServer?.start()
            
            try {
                val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val ipAddress = if (wifiManager != null) {
                    Formatter.formatIpAddress(wifiManager.connectionInfo.ipAddress)
                } else {
                    "Unavailable"
                }
                tvInstructions.text = "To upload wallpapers, visit http://$ipAddress:8080 on your phone."
            } catch (e: Exception) {
                e.printStackTrace()
                tvInstructions.text = "To upload wallpapers, visit http://<TV_IP>:8080 on your phone."
            }
            
        } catch (e: IOException) {
            e.printStackTrace()
            tvInstructions.text = "Failed to start Web Server: ${e.message}"
        }
    }

    private fun importWallpaper(uri: android.net.Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val wallpaperDir = java.io.File(filesDir, "wallpapers")
            if (!wallpaperDir.exists()) wallpaperDir.mkdirs()
            
            val destFile = java.io.File(wallpaperDir, "imported_${System.currentTimeMillis()}.jpg")
            val outputStream = java.io.FileOutputStream(destFile)
            
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()
            
            loadWallpaperList()
            android.widget.Toast.makeText(this, "Wallpaper Imported", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            android.widget.Toast.makeText(this, "Import Failed", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun importFromFolderPath(folderPath: String) {
        try {
            val wallpaperDir = java.io.File(filesDir, "wallpapers")
            if (!wallpaperDir.exists()) wallpaperDir.mkdirs()

            var importCount = 0
            val sourceFolder = java.io.File(folderPath)
            
            sourceFolder.listFiles()?.forEach { file ->
                if (file.isFile && file.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "bmp")) {
                    try {
                        val destFile = java.io.File(wallpaperDir, "folder_${System.currentTimeMillis()}_${file.name}")
                        file.copyTo(destFile, overwrite = false)
                        importCount++
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
            
            loadWallpaperList()
            android.widget.Toast.makeText(this, "Imported $importCount photos from folder", android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            android.widget.Toast.makeText(this, "Folder import failed: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun loadWallpaperList() {
        layoutWallpapers.removeAllViews()
        val wallpaperDir = java.io.File(filesDir, "wallpapers")
        if (wallpaperDir.exists()) {
            val files = wallpaperDir.listFiles()
            val selectedWallpaper = sharedPref.getString("selected_wallpaper", "")
            
            if (files.isNullOrEmpty()) {
                val noFilesView = TextView(this)
                noFilesView.text = "No wallpapers found. Import some!"
                noFilesView.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                noFilesView.textSize = 16f
                noFilesView.setPadding(16, 16, 16, 16)
                layoutWallpapers.addView(noFilesView)
            } else {
                files.forEach { file ->
                    val radioButton = android.widget.RadioButton(this)
                    radioButton.text = file.name
                    radioButton.textSize = 16f
                    radioButton.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
                    radioButton.setPadding(16, 16, 16, 16)
                    radioButton.isFocusable = true
                    radioButton.isFocusableInTouchMode = true
                    
                    // Set checked state
                    radioButton.isChecked = (file.name == selectedWallpaper)
                    
                    // Highlight selected item
                    if (file.name == selectedWallpaper) {
                        radioButton.setBackgroundColor(ContextCompat.getColor(this, R.color.groovy_blue))
                        radioButton.setTextColor(ContextCompat.getColor(this, R.color.black)) // Black text on blue
                    } else {
                        radioButton.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                        radioButton.setTextColor(ContextCompat.getColor(this, R.color.text_primary)) // White text on dark
                    }
                    
                    // Click to select
                    radioButton.setOnClickListener {
                        sharedPref.edit().putString("selected_wallpaper", file.name).apply()
                        loadWallpaperList() // Refresh to show selection
                    }
                    
                    // Long click to delete
                    radioButton.setOnLongClickListener {
                        val builder = android.app.AlertDialog.Builder(this)
                        builder.setTitle("Delete Wallpaper")
                        builder.setMessage("Delete ${file.name}?")
                        builder.setPositiveButton("Delete") { _, _ ->
                            file.delete()
                            loadWallpaperList()
                        }
                        builder.setNegativeButton("Cancel", null)
                        builder.show()
                        true
                    }
                    layoutWallpapers.addView(radioButton)
                }
            }
        } else {
             val noFilesView = TextView(this)
             noFilesView.text = "No wallpapers found. Import some!"
             noFilesView.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
             noFilesView.textSize = 16f
             noFilesView.setPadding(16, 16, 16, 16)
             layoutWallpapers.addView(noFilesView)
        }
    }


    private fun requestStoragePermissions() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+ - Request MANAGE_EXTERNAL_STORAGE
                // Skip on TV since it might not support this Intent
                if (!Environment.isExternalStorageManager()) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        intent.data = Uri.parse("package:$packageName")
                        startActivity(intent)
                    } catch (e: Exception) {
                        // Silently fail on TV - we use internal storage anyway
                        e.printStackTrace()
                    }
                }
            } else {
                // Android 10 and below - Request READ_EXTERNAL_STORAGE
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) 
                    != PackageManager.PERMISSION_GRANTED) {
                    try {
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                            100
                        )
                    } catch (e: Exception) {
                        // Silently fail on TV
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            // Catch any other permission-related errors
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        webServer?.stop()
    }
    
    // Google Drive Methods
    private fun signIn() {
        val signInIntent = mGoogleSignInClient?.signInIntent
        signInLauncher.launch(signInIntent)
    }
    
    private fun handleSignInResult(account: com.google.android.gms.auth.api.signin.GoogleSignInAccount) {
        val credential = GoogleAccountCredential.usingOAuth2(
            this, Collections.singleton(DriveScopes.DRIVE_READONLY)
        )
        credential.selectedAccount = account.account
        val googleDriveService = Drive.Builder(
            NetHttpTransport(),
            GsonFactory(),
            credential
        )
        .setApplicationName("TVScreensaver")
        .build()

        mDriveServiceHelper = DriveServiceHelper(googleDriveService)
        
        findViewById<Button>(R.id.btnGoogleSignIn).text = "Signed in as ${account.email}"
        findViewById<Button>(R.id.btnSelectDriveFolder).isEnabled = true
        
        // Update folder name if already selected
        val folderName = sharedPref.getString("drive_folder_name", "No folder selected")
        findViewById<TextView>(R.id.tvDriveFolderName).text = folderName
        
        // Show success Toast
        android.widget.Toast.makeText(this, "Sign-in successful! Click 'Select Drive Folder' button below.", android.widget.Toast.LENGTH_LONG).show()
        
        // Auto-open folder picker if no folder selected yet
        if (folderName == "No folder selected") {
            // Delay slightly so UI can update
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                openDriveFolderPicker()
            }, 500)
        }
    }
    
    private fun openDriveFolderPicker() {
        if (mDriveServiceHelper == null) return
        
        val progressDialog = android.app.ProgressDialog(this)
        progressDialog.setMessage("Loading folders...")
        progressDialog.show()
        
        mDriveServiceHelper?.queryFolders()
            ?.addOnSuccessListener { files ->
                progressDialog.dismiss()
                val folderNames = files.map { it.name }.toTypedArray()
                val folderIds = files.map { it.id }.toTypedArray()
                
                val builder = android.app.AlertDialog.Builder(this)
                builder.setTitle("Select Drive Folder")
                builder.setItems(folderNames) { _, which ->
                    val selectedFolderId = folderIds[which]
                    val selectedFolderName = folderNames[which]
                    
                    sharedPref.edit()
                        .putString("drive_folder_id", selectedFolderId)
                        .putString("drive_folder_name", selectedFolderName)
                        .apply()
                        
                    findViewById<TextView>(R.id.tvDriveFolderName).text = selectedFolderName
                    android.widget.Toast.makeText(this, "Selected: $selectedFolderName", android.widget.Toast.LENGTH_SHORT).show()
                }
                builder.show()
            }
            ?.addOnFailureListener { e ->
                progressDialog.dismiss()
                android.widget.Toast.makeText(this, "Failed to list folders: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
    }

    private fun setupNavigation() {
        val navItems = listOf(navEsp32, navWallpaper, navClock, navPreview, navDrive, navList)
        val contentViews = listOf(contentEsp32, contentWallpaper, contentClock, contentPreview, contentDrive, contentList)

        navItems.forEachIndexed { index, navItem ->
            navItem.setOnClickListener {
                switchContent(index, navItems, contentViews)
            }
            navItem.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    switchContent(index, navItems, contentViews)
                }
            }
        }

        // Default selection
        switchContent(0, navItems, contentViews)
    }

    private fun switchContent(index: Int, navItems: List<TextView>, contentViews: List<android.view.View>) {
        // Update Content Visibility
        contentViews.forEachIndexed { i, view ->
            view.visibility = if (i == index) android.view.View.VISIBLE else android.view.View.GONE
        }

        // Update Nav Selection State
        navItems.forEachIndexed { i, navItem ->
            navItem.isSelected = (i == index)
            if (i == index) {
                navItem.setBackgroundResource(R.drawable.sidebar_selector) // Ensure selector is applied
            }
        }

        // Refresh wallpaper list if switching to that tab
        if (index == 5) {
            loadWallpaperList()
        }
    }
}
