package com.example.tvscreensaver

object DriveConfig {
    const val WEB_CLIENT_ID = "950906764084-6g5cdj66k0qq5ssorrh8rbkj3b6n0ehq.apps.googleusercontent.com"
    const val SCOPES = "https://www.googleapis.com/auth/drive.readonly"
}
