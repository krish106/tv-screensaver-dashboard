package com.example.tvscreensaver

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.service.dreams.DreamService
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.tasks.Tasks
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ScreensaverService : DreamService() {

    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvHumidity: TextView
    private lateinit var ivWallpaper: ImageView
    
    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient()
    private var job: Job? = null
    private var wallpaperJob: Job? = null
    private var currentWallpaperPath: String = ""
    
    // Google Drive
    private var mDriveServiceHelper: DriveServiceHelper? = null
    private var driveFiles: List<com.google.api.services.drive.model.File> = emptyList()
    
    private val timeRunnable = object : Runnable {
        override fun run() {
            val currentTime = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val currentDate = SimpleDateFormat("EEE, MMM dd", Locale.getDefault()).format(Date())
            tvTime.text = currentTime
            tvDate.text = currentDate
            handler.postDelayed(this, 1000)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = true
        isFullscreen = true
        setContentView(R.layout.service_screensaver)

        tvTime = findViewById(R.id.tvTime)
        tvDate = findViewById(R.id.tvDate)
        tvTemp = findViewById(R.id.tvTemp)
        tvHumidity = findViewById(R.id.tvHumidity)
        ivWallpaper = findViewById(R.id.ivWallpaper)

        // Apply Clock Style
        applyClockStyle()

        // Apply Clock Position
        applyClockPosition()

        // Start Time Update
        handler.post(timeRunnable)
        
        // Initialize Drive Helper if needed
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val driveFolderId = sharedPref.getString("drive_folder_id", null)
        
        if (driveFolderId != null) {
            val account = GoogleSignIn.getLastSignedInAccount(this)
            if (account != null) {
                val credential = GoogleAccountCredential.usingOAuth2(
                    this, Collections.singleton(DriveScopes.DRIVE_READONLY)
                )
                credential.selectedAccount = account.account
                val googleDriveService = Drive.Builder(
                    NetHttpTransport(),
                    GsonFactory(),
                    credential
                )
                .setApplicationName("TVScreensaver")
                .build()

                mDriveServiceHelper = DriveServiceHelper(googleDriveService)
            }
        }

        // Start Wallpaper Rotation
        startWallpaperRotation()

        // Start Data Fetch
        startDataFetch()
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) {
            return when (event.keyCode) {
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    changeWallpaper(1)
                    true
                }
                android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                    changeWallpaper(-1)
                    true
                }
                else -> super.dispatchKeyEvent(event)
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun changeWallpaper(direction: Int) {
        // Local wallpaper navigation logic (simplified for now, mainly for local files)
        val wallpaperDir = java.io.File(filesDir, "wallpapers")
        if (wallpaperDir.exists()) {
            val files = wallpaperDir.listFiles()?.filter { 
                it.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "bmp") 
            }
            
            if (files != null && files.isNotEmpty()) {
                val currentFile = files.find { it.absolutePath == currentWallpaperPath }
                val currentIndex = if (currentFile != null) files.indexOf(currentFile) else 0
                
                var newIndex = currentIndex + direction
                if (newIndex < 0) newIndex = files.size - 1
                if (newIndex >= files.size) newIndex = 0
                
                currentWallpaperPath = files[newIndex].absolutePath
                ivWallpaper.setImageURI(android.net.Uri.fromFile(files[newIndex]))
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(timeRunnable)
        job?.cancel()
        wallpaperJob?.cancel()
    }

    private fun startWallpaperRotation() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val mode = sharedPref.getString("wallpaper_mode", "rotating")
        val interval = sharedPref.getInt("rotation_interval", 30) * 1000L
        val selectedWallpaper = sharedPref.getString("selected_wallpaper", "")
        val driveFolderId = sharedPref.getString("drive_folder_id", null)

        // Check if Drive mode is active
        if (driveFolderId != null && mDriveServiceHelper != null) {
            wallpaperJob = CoroutineScope(Dispatchers.IO).launch {
                while (isActive) {
                    try {
                        if (driveFiles.isEmpty()) {
                            // Fetch files from Drive
                            val task = mDriveServiceHelper!!.queryImagesInFolder(driveFolderId)
                            driveFiles = Tasks.await(task)
                        }
                        
                        if (driveFiles.isNotEmpty()) {
                            // Pick random file
                            val file = driveFiles.random()
                            val cacheFile = File(cacheDir, file.id + "_" + file.name)
                            
                            if (!cacheFile.exists()) {
                                // Download to cache
                                val downloadTask = mDriveServiceHelper!!.downloadFile(file.id, cacheFile)
                                Tasks.await(downloadTask)
                            }
                            
                            withContext(Dispatchers.Main) {
                                displayWallpaper(cacheFile)
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    delay(interval)
                }
            }
            return
        }

        // Fallback to Local Mode
        val wallpaperDir = File(filesDir, "wallpapers")
        if (!wallpaperDir.exists() || wallpaperDir.listFiles()?.isEmpty() == true) return

        val files = wallpaperDir.listFiles()?.toList() ?: emptyList()

        wallpaperJob = CoroutineScope(Dispatchers.Main).launch {
            if (mode == "static") {
                val file = files.find { it.name == selectedWallpaper } ?: files.random()
                displayWallpaper(file)
            } else {
                var index = 0
                while (isActive) {
                    if (files.isNotEmpty()) {
                        displayWallpaper(files[index])
                        index = (index + 1) % files.size
                    }
                    delay(interval)
                }
            }
        }
    }

    private fun displayWallpaper(file: File) {
        try {
            currentWallpaperPath = file.absolutePath
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            ivWallpaper.setImageBitmap(bitmap)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startDataFetch() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val espIp = sharedPref.getString("esp_ip", "")

        if (espIp.isNullOrEmpty()) {
            tvTemp.text = "Set ESP IP in App"
            return
        }

        job = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                try {
                    val request = Request.Builder()
                        .url("http://$espIp/data")
                        .build()

                    val response = client.newCall(request).execute()
                    val jsonData = response.body?.string()

                    if (jsonData != null) {
                        val json = JSONObject(jsonData)
                        val temp = json.optDouble("temperature", 0.0)
                        val humidity = json.optDouble("humidity", 0.0)

                        withContext(Dispatchers.Main) {
                            tvTemp.text = "Temp: $temp°C"
                            tvHumidity.text = "Humidity: $humidity%"
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(10000) // Update every 10 seconds
            }
        }
    }

    private fun applyClockStyle() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val clockStyle = sharedPref.getString("clock_style", "Classic Bold")
        val textScale = sharedPref.getFloat("text_scale", 1.0f)

        when (clockStyle) {
            "Classic Bold" -> {
                tvTime.typeface = android.graphics.Typeface.DEFAULT_BOLD
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.DEFAULT
                tvDate.textSize = 14f * textScale
            }
            "Modern Thin" -> {
                tvTime.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 36f * textScale
                tvDate.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 15f * textScale
            }
            "Digital Mono" -> {
                tvTime.typeface = android.graphics.Typeface.MONOSPACE
                tvTime.textSize = 30f * textScale
                tvDate.typeface = android.graphics.Typeface.MONOSPACE
                tvDate.textSize = 12f * textScale
            }
            "Elegant Script" -> {
                tvTime.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.ITALIC)
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.ITALIC)
                tvDate.textSize = 14f * textScale
            }
            "Retro Condensed" -> {
                tvTime.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
                tvTime.textSize = 34f * textScale
                tvDate.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 14f * textScale
            }
            "Futuristic" -> {
                tvTime.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 38f * textScale
                tvDate.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 16f * textScale
            }
            "Minimalist Light" -> {
                tvTime.typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 40f * textScale
                tvDate.typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 16f * textScale
            }
            "Bold Italic" -> {
                tvTime.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD_ITALIC)
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
                tvDate.textSize = 14f * textScale
            }
            "Rounded Casual" -> {
                tvTime.typeface = android.graphics.Typeface.create("casual", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.create("casual", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 14f * textScale
            }
            "Sharp Serif" -> {
                tvTime.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
                tvTime.textSize = 30f * textScale
                tvDate.typeface = android.graphics.Typeface.SERIF
                tvDate.textSize = 13f * textScale
            }
            "Playful Sans" -> {
                tvTime.typeface = android.graphics.Typeface.SANS_SERIF
                tvTime.textSize = 34f * textScale
                tvDate.typeface = android.graphics.Typeface.SANS_SERIF
                tvDate.textSize = 15f * textScale
            }
            "Professional" -> {
                tvTime.typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 14f * textScale
            }
            "Artistic Handwritten" -> {
                tvTime.typeface = android.graphics.Typeface.create("cursive", android.graphics.Typeface.NORMAL)
                tvTime.textSize = 34f * textScale
                tvDate.typeface = android.graphics.Typeface.create("cursive", android.graphics.Typeface.NORMAL)
                tvDate.textSize = 15f * textScale
            }
            else -> {
                tvTime.typeface = android.graphics.Typeface.DEFAULT_BOLD
                tvTime.textSize = 32f * textScale
                tvDate.typeface = android.graphics.Typeface.DEFAULT
                tvDate.textSize = 14f * textScale
            }
        }
        
        // Scale Temp and Humidity as well
        tvTemp.textSize = 16f * textScale
        tvHumidity.textSize = 16f * textScale
    }

    private fun applyClockPosition() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val clockPosition = sharedPref.getString("clock_position", "Bottom-Right") ?: "Bottom-Right"

        val layoutClock = findViewById<android.widget.LinearLayout>(R.id.layoutClock)
        val params = layoutClock.layoutParams as android.widget.FrameLayout.LayoutParams

        params.gravity = when (clockPosition) {
            "Top-Left" -> android.view.Gravity.TOP or android.view.Gravity.START
            "Top-Center" -> android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
            "Top-Right" -> android.view.Gravity.TOP or android.view.Gravity.END
            "Mid-Left" -> android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            "Center" -> android.view.Gravity.CENTER
            "Mid-Right" -> android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END
            "Bottom-Left" -> android.view.Gravity.BOTTOM or android.view.Gravity.START
            "Bottom-Center" -> android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
            "Bottom-Right" -> android.view.Gravity.BOTTOM or android.view.Gravity.END
            else -> android.view.Gravity.BOTTOM or android.view.Gravity.END
        }

        layoutClock.layoutParams = params
    }
}
