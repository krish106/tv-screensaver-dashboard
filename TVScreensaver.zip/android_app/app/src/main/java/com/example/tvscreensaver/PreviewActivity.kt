package com.example.tvscreensaver

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class PreviewActivity : AppCompatActivity() {
    
    private lateinit var ivPreview: ImageView
    private lateinit var tvPreviewTime: TextView
    private lateinit var tvPreviewDate: TextView
    private lateinit var tvPreviewTemp: TextView
    private lateinit var tvPreviewHumidity: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)
        
        ivPreview = findViewById(R.id.ivPreview)
        tvPreviewTime = findViewById(R.id.tvPreviewTime)
        tvPreviewDate = findViewById(R.id.tvPreviewDate)
        tvPreviewTemp = findViewById(R.id.tvPreviewTemp)
        tvPreviewHumidity = findViewById(R.id.tvPreviewHumidity)
        
        val btnClose = findViewById<Button>(R.id.btnClosePreview)
        btnClose.setOnClickListener {
            finish()
        }
        
        loadPreview()
    }
    
    private fun loadPreview() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        
        // Load wallpaper
        val wallpaperDir = java.io.File(filesDir, "wallpapers")
        if (wallpaperDir.exists() && wallpaperDir.listFiles()?.isNotEmpty() == true) {
            val files = wallpaperDir.listFiles()
            ivPreview.setImageBitmap(BitmapFactory.decodeFile(files?.first()?.absolutePath))
        } else {
            // Use default aurora wallpaper
            ivPreview.setImageResource(R.drawable.default_wallpaper)
        }
        
        // Set current time
        tvPreviewTime.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        tvPreviewDate.text = SimpleDateFormat("EEE, MMM dd", Locale.getDefault()).format(Date())
        tvPreviewTemp.text = "Temp: 22°C"
        tvPreviewHumidity.text = "Humidity: 65%"
        
        // Apply clock style
        applyClockStyle()
        
        // Apply clock position
        applyClockPosition()
    }
    
    private fun applyClockStyle() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val clockStyle = sharedPref.getString("clock_style", "Classic Bold")
        val textScale = sharedPref.getFloat("text_scale", 1.0f)

        when (clockStyle) {
            "Classic Bold" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.DEFAULT_BOLD
                tvPreviewTime.textSize = 32f * textScale
            }
            "Modern Thin" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 36f * textScale
            }
            "Digital Mono" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.MONOSPACE
                tvPreviewTime.textSize = 30f * textScale
            }
            "Elegant Script" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.ITALIC)
                tvPreviewTime.textSize = 32f * textScale
            }
            "Retro Condensed" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
                tvPreviewTime.textSize = 34f * textScale
            }
            "Futuristic" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 38f * textScale
            }
            "Minimalist Light" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 40f * textScale
            }
            "Bold Italic" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD_ITALIC)
                tvPreviewTime.textSize = 32f * textScale
            }
            "Rounded Casual" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("casual", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 32f * textScale
            }
            "Sharp Serif" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
                tvPreviewTime.textSize = 30f * textScale
            }
            "Playful Sans" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.SANS_SERIF
                tvPreviewTime.textSize = 34f * textScale
            }
            "Professional" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 32f * textScale
            }
            "Artistic Handwritten" -> {
                tvPreviewTime.typeface = android.graphics.Typeface.create("cursive", android.graphics.Typeface.NORMAL)
                tvPreviewTime.textSize = 34f * textScale
            }
        }
        
        // Scale Date, Temp, Humidity
        tvPreviewDate.textSize = 14f * textScale
        tvPreviewTemp.textSize = 16f * textScale
        tvPreviewHumidity.textSize = 16f * textScale
    }
    
    private fun applyClockPosition() {
        val sharedPref = getSharedPreferences("TvScreensaverPrefs", Context.MODE_PRIVATE)
        val clockPosition = sharedPref.getString("clock_position", "Bottom-Right")

        val layoutClock = findViewById<android.widget.LinearLayout>(R.id.layoutPreviewClock)
        val params = layoutClock.layoutParams as android.widget.FrameLayout.LayoutParams

        params.gravity = when (clockPosition) {
            "Top-Left" -> android.view.Gravity.TOP or android.view.Gravity.START
            "Top-Center" -> android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
            "Top-Right" -> android.view.Gravity.TOP or android.view.Gravity.END
            "Mid-Left" -> android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            "Center" -> android.view.Gravity.CENTER
            "Mid-Right" -> android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END
            "Bottom-Left" -> android.view.Gravity.BOTTOM or android.view.Gravity.START
            "Bottom-Center" -> android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
            "Bottom-Right" -> android.view.Gravity.BOTTOM or android.view.Gravity.END
            else -> android.view.Gravity.BOTTOM or android.view.Gravity.END
        }

        layoutClock.layoutParams = params
    }
}
