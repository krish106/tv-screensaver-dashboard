package com.example.tvscreensaver

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class WebServer(private val context: Context, port: Int) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        if (session.method == Method.POST) {
            return handleUpload(session)
        }
        return handleForm()
    }

    private fun handleForm(): Response {
        val html = """
            <html>
            <body>
                <h1>Upload Wallpaper</h1>
                <form action="/" method="post" enctype="multipart/form-data">
                    <input type="file" name="file" accept="image/*" />
                    <input type="submit" value="Upload" />
                </form>
            </body>
            </html>
        """.trimIndent()
        return newFixedLengthResponse(html)
    }

    private fun handleUpload(session: IHTTPSession): Response {
        val files = HashMap<String, String>()
        try {
            session.parseBody(files)
        } catch (e: IOException) {
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Internal Error")
        } catch (e: ResponseException) {
            return newFixedLengthResponse(e.status, MIME_PLAINTEXT, e.message)
        }

        // NanoHTTPD stores temp files in 'files' map. Key is form field name, Value is temp file path.
        // But wait, parseBody puts the *location* of the temp file in the map.
        // We need to find the file parameter.
        
        // Actually, for multipart, NanoHTTPD puts the temp file path in 'files' map with the input name as key.
        // And parameters in 'parms' map.
        
        val tempFilePath = files["file"]
        if (tempFilePath != null) {
            val tempFile = File(tempFilePath)
            val wallpaperDir = File(context.filesDir, "wallpapers")
            if (!wallpaperDir.exists()) wallpaperDir.mkdirs()
            
            val destFile = File(wallpaperDir, "wallpaper_${System.currentTimeMillis()}.jpg")
            tempFile.copyTo(destFile, overwrite = true)
            
            return newFixedLengthResponse("Upload Successful! File saved.")
        }

        return newFixedLengthResponse("No file uploaded.")
    }
}
