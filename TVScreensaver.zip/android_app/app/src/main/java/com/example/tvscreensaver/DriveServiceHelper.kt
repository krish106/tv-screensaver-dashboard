package com.example.tvscreensaver

import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.api.client.http.ByteArrayContent
import com.google.api.services.drive.Drive
import com.google.api.services.drive.model.File
import com.google.api.services.drive.model.FileList
import java.io.IOException
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * A utility for performing read/write operations on Drive files via the REST API and opening a
 * file picker UI via Storage Access Framework.
 */
class DriveServiceHelper(private val mDriveService: Drive) {
    private val mExecutor: Executor = Executors.newSingleThreadExecutor()

    /**
     * Creates a text file in the user's My Drive folder.
     */
    fun createFile(title: String?): Task<String> {
        return Tasks.call(mExecutor) {
            val metadata = File()
                .setParents(listOf("root"))
                .setMimeType("text/plain")
                .setName(title)
            val googleFile = mDriveService.files().create(metadata, ByteArrayContent.fromString("text/plain", ""))
                .execute()
            if (googleFile == null) {
                throw IOException("Null result when requesting file creation.")
            }
            googleFile.id
        }
    }

    /**
     * Opens the file identified by {@code fileId} and returns a {@link Pair} of its name and
     * contents.
     */
    fun readFile(fileId: String?): Task<Pair<String, String>> {
        return Tasks.call(mExecutor) {
            // Retrieve the metadata as a File object.
            val metadata = mDriveService.files().get(fileId).execute()
            val name = metadata.name
            
            // Stream the file contents to a String.
            mDriveService.files().get(fileId).executeMediaAsInputStream().use { inputStream ->
                val contents = inputStream.bufferedReader().use { it.readText() }
                Pair(name, contents)
            }
        }
    }

    /**
     * Queries for all folders in the user's Drive.
     */
    fun queryFolders(): Task<List<File>> {
        return Tasks.call(mExecutor) {
            val files = mutableListOf<File>()
            var pageToken: String? = null
            do {
                val result: FileList = mDriveService.files().list()
                    .setQ("mimeType = 'application/vnd.google-apps.folder' and trashed = false")
                    .setSpaces("drive")
                    .setFields("nextPageToken, files(id, name)")
                    .setPageToken(pageToken)
                    .execute()
                
                files.addAll(result.files)
                pageToken = result.nextPageToken
            } while (pageToken != null)
            files
        }
    }

    /**
     * Queries for all image files in a specific folder.
     */
    fun queryImagesInFolder(folderId: String): Task<List<File>> {
        return Tasks.call(mExecutor) {
            val files = mutableListOf<File>()
            var pageToken: String? = null
            do {
                val result: FileList = mDriveService.files().list()
                    .setQ("'$folderId' in parents and (mimeType contains 'image/') and trashed = false")
                    .setSpaces("drive")
                    .setFields("nextPageToken, files(id, name, mimeType, webContentLink, webViewLink, thumbnailLink)")
                    .setPageToken(pageToken)
                    .execute()

                files.addAll(result.files)
                pageToken = result.nextPageToken
            } while (pageToken != null)
            files
        }
    }

    /**
     * Downloads a file to the specified local file.
     */
    fun downloadFile(fileId: String, targetFile: java.io.File): Task<Void?> {
        return Tasks.call(mExecutor) {
            try {
                java.io.FileOutputStream(targetFile).use { outputStream ->
                    mDriveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
                }
            } catch (e: IOException) {
                throw e
            }
            null
        }
    }
}
