package com.example.tvscreensaver

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class FolderBrowserActivity : AppCompatActivity() {

    private lateinit var tvCurrentPath: TextView
    private lateinit var rvFolders: RecyclerView
    private lateinit var btnCancel: Button
    private lateinit var btnChoose: Button
    private lateinit var adapter: FolderAdapter
    
    private var currentDirectory: File = Environment.getExternalStorageDirectory()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder_browser)

        tvCurrentPath = findViewById(R.id.tvCurrentPath)
        rvFolders = findViewById(R.id.rvFolders)
        btnCancel = findViewById(R.id.btnCancel)
        btnChoose = findViewById(R.id.btnChoose)

        // Setup RecyclerView
        adapter = FolderAdapter { folder ->
            navigateToFolder(folder)
        }
        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolders.adapter = adapter

        // Load initial directory
        loadDirectory(currentDirectory)

        // Cancel button
        btnCancel.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }

        // Choose button
        btnChoose.setOnClickListener {
            val intent = Intent()
            intent.putExtra("folder_path", currentDirectory.absolutePath)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }

    private fun loadDirectory(directory: File) {
        try {
            currentDirectory = directory
            tvCurrentPath.text = directory.absolutePath

            val folders = mutableListOf<File>()
            
            // Add parent directory option if not at root
            if (directory.parent != null) {
                folders.add(File(directory.parent!!).apply {
                    // Mark as parent with special name
                })
            }

            // Add all subdirectories
            directory.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.let {
                folders.addAll(it)
            }

            adapter.updateFolders(folders, directory.parent != null)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Cannot access this folder", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToFolder(folder: File) {
        loadDirectory(folder)
    }

    override fun onBackPressed() {
        if (currentDirectory.parent != null) {
            loadDirectory(File(currentDirectory.parent!!))
        } else {
            super.onBackPressed()
        }
    }
}

// Adapter for folder list
class FolderAdapter(private val onFolderClick: (File) -> Unit) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    private var folders = listOf<File>()
    private var hasParent = false

    fun updateFolders(newFolders: List<File>, hasParent: Boolean) {
        this.folders = newFolders
        this.hasParent = hasParent
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): FolderViewHolder {
        val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return FolderViewHolder(view)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        val folder = folders[position]
        
        if (position == 0 && hasParent) {
            // Parent directory
            holder.tvFolderName.text = ".."
            holder.ivFolderIcon.setImageResource(android.R.drawable.ic_menu_revert)
            holder.tvPhotoCount.text = ""
        } else {
            holder.tvFolderName.text = folder.name
            holder.ivFolderIcon.setImageResource(android.R.drawable.ic_menu_upload)
            
            // Count photos in this folder
            val photoCount = countPhotosInFolder(folder)
            holder.tvPhotoCount.text = if (photoCount > 0) "$photoCount photos" else ""
        }

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    private fun countPhotosInFolder(folder: File): Int {
        return try {
            folder.listFiles()?.count { file ->
                file.isFile && file.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "bmp")
            } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    override fun getItemCount() = folders.size

    class FolderViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val ivFolderIcon: android.widget.ImageView = view.findViewById(R.id.ivFolderIcon)
        val tvPhotoCount: TextView = view.findViewById(R.id.tvPhotoCount)
    }
}
